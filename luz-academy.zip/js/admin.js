const SENHA = "1234";

function login() {
  if (document.getElementById("senha").value !== SENHA) {
    alert("Senha incorreta");
    return;
  }

  document.querySelector(".container").innerHTML += `
    <h3>Pedidos Pendentes</h3>
    <div id="lista"></div>
  `;

  carregarPedidos();
}

function carregarPedidos() {
  fetch("api/pedidos.json")
    .then(r => r.json())
    .then(pedidos => {
      const div = document.getElementById("lista");
      div.innerHTML = "";

      pedidos.forEach((p, i) => {
        if (p.status === "pendente") {
          div.innerHTML += `
            <div class="card">
              <b>${p.nick}</b><br>
              VIP: ${p.vip}<br>
              Valor: R$ ${p.valor}<br>
              IDF: ${p.idf ?? "Não informado"}<br><br>
              <button class="btn" onclick="confirmarEntrega()">Confirmar entrega</button>
            </div>
          `;
        }
      });
    });
}

function confirmarEntrega() {
  alert(
    "Entrega confirmada!\n\n" +
    "Agora a GM vai entregar o VIP automaticamente."
  );
}