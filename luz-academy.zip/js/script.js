let pedidos = [];

fetch("api/pedidos.json")
  .then(r => r.json())
  .then(d => pedidos = d);

function abrir(id) {
  document.querySelectorAll(".pagina").forEach(p => p.classList.remove("ativa"));
  document.getElementById(id).classList.add("ativa");
}

function toggleTheme() {
  document.body.classList.toggle("light");
  document.body.classList.toggle("dark");
}

function comprar(vip, valor) {
  const nick = document.getElementById("nick").value.trim();
  const idf = document.getElementById("idf").value;

  if (!nick) {
    alert("Digite seu nick!");
    return;
  }

  if (pedidos.find(p => p.nick === nick && p.vip === vip && p.status === "pendente")) {
    alert("Você já tem um pedido pendente desse VIP!");
    return;
  }

  alert(
    "Pedido criado!\n\n" +
    "VIP: " + vip +
    "\nValor: R$ " + valor +
    "\n\nPIX: j433486@gmail.com\n" +
    "Após o pagamento, aguarde a entrega."
  );
}